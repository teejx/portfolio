import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

class MainMenu extends JFrame {
    JButton b1;
    JLabel l1;

    MainMenu() {

        setContentPane(new JLabel(new ImageIcon("untitled.gif")));
        setLayout(new FlowLayout());

        setLayout(null);
        JLabel imageLabel = new JLabel();
        ImageIcon titleImage = new ImageIcon("PORTFOLIO.png");
        imageLabel.setIcon(titleImage);
        imageLabel.setBounds(280,12,700,350);
        
        b1 = new JButton();
        b1.setBounds(570,350,100,40);
        b1Handler handler = new b1Handler();
        b1.addActionListener(handler);
        b1.setIcon(new ImageIcon("enter.png"));


        add(imageLabel);
        add(b1);
        setSize(1280, 665);
        setTitle("Portfolio by Teej");
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setVisible(true);
        setResizable(false);
    }
    private class b1Handler implements ActionListener{
        public void actionPerformed(ActionEvent event) {
            new Profile();
            dispose();
        }

       
    }
}