import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

class Profile extends JFrame {
    JButton b1;
    JButton b2;
    JLabel l1;

    Profile() {

        setContentPane(new JLabel(new ImageIcon("myself.png")));
        setLayout(new FlowLayout());

        setLayout(null);
        b1 = new JButton();
        b1.setBounds(530,583,100,40);
        b1Handler handler = new b1Handler();
        b1.addActionListener(handler);
        b1.setIcon(new ImageIcon("back.png"));

        b2 = new JButton();
        b2.setBounds(635,583,100,40);
        b2Handler handler1 = new b2Handler();
        b2.addActionListener(handler1);
        b2.setIcon(new ImageIcon("next.png"));

        add(b1);
        add(b2);
        setSize(1280, 665);
        setTitle("Portfolio by Teej");
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setVisible(true);
        setResizable(false);
    }
    private class b1Handler implements ActionListener{
        public void actionPerformed(ActionEvent event) {
            new MainMenu();
            dispose();
        }

       
    }
    private class b2Handler implements ActionListener{
        public void actionPerformed(ActionEvent event) {
            new Skills();
            dispose();
        }

       
    }
}